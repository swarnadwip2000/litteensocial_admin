 <!-- Start Footer
    ============================================= -->
    <footer class="bg-light">

        <!-- Start Footer Bottom -->
        <div class="footer-bottom" style="margin-top: 0;">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-12 text-center">
                            <p><a href="#">© Copyright {{date('Y')}} by Lit Teen Social & Adventures</a> | All Rights
                                Reserved.</p>
                        </div>
                        <!-- <div class="col-md-6 text-right link ">
                            <ul>
                                <li>
                                    <a href="#">Terms</a>
                                </li>
                                <li>
                                    <a href="#">Privacy</a>
                                </li>
                                <li>
                                    <a href="#">Support</a>
                                </li>
                            </ul>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer Bottom -->
    </footer>
    <!-- End Footer -->